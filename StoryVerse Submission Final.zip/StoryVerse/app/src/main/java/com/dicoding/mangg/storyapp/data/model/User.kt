package com.dicoding.mangg.storyapp.data.model

data class User(
    val name: String,
    val token: String,
    val isLogin: Boolean
)